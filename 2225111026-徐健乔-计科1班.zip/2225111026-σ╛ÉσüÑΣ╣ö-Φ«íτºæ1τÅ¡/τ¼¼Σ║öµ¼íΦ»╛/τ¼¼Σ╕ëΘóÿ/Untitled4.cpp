#include<iostream>
#include<iomanip>
using namespace std;
void down(){
	for(int i=1;i<=9;i++){
		cout<<i<<"    ";
		for(int j=1;j<=i;j++){
			if(j<=i){
		    cout<<setw(5)<<setfill(' ')<<setiosflags(ios::left)<<i*j;
			}
		}	 
		cout<<endl;
}
}
void up(){
	for(int i=1;i<=9;i++){
		cout<<i<<"    ";
		for(int j=1;j<=9;j++){
			if(j>=i){
		    cout<<setw(5)<<setfill(' ')<<setiosflags(ios::left)<<i*j;
			}
			else
			cout<<"     ";
		}	 
		cout<<endl;
}
}
