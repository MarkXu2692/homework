#include <iostream>
#include <iomanip>
using namespace std;
int main(){
void down();
void up();
	cout<<"*";
	for(int a=1;a<=9;a++){
		cout<<"    "<<a;
	} 
	cout<<endl;
	for(int b=1;b<=47;b++){
		cout<<"-";
	}
		cout<<endl;
	down();//for the down left 
	//--------------------------------------------------
	cout<<endl;
		cout<<"*";
	for(int n=1;n<=9;n++){
		cout<<"    "<<n;
	} 
	cout<<endl;
	for(int m=1;m<=47;m++){
		cout<<"-";
	}
		cout<<endl;
		up();//for the up right
}
