#include<iostream>
#include<iomanip>
using namespace std;

void down(int, int)
void up(int,int)
