#include<iostream>
using namespace std;
int main()
{	int di(int,int);
	int mu(int,int);
	int a,b;
	cout<<"Please input the integers:";
	cin>>a>>b;
	cout<<"the greatest common divisor:"<<di(a,b)<<endl;
	cout<<"the least common multiple:"<<mu(a,b)<<endl;
} 
int di(int x,int y){
	int di,t;
	if(x>y)
	t=y;
	else
	t=x;
	for(int i=1;i<=t;i++){
		if(x%i==0 && y%i==0)
		di=i;	
	}
	return di;
}// for the divisor
int mu(int x,int y){
	int mu,t;
	if(x>y)
	t=x;
	else
	t=y;
	for(int i=x*y;i>=t;i--){
		if(i%x==0 && i%y==0)
		mu=i;
	}
	return mu;
}//for the multiple

