#include <iostream>
using namespace std;
void convert(int n);
int main(){
int i;
cout<<"input an integer:";
cin>>i;
convert(i);
cout<<endl;
return 0;
}
void convert(int n){
char c;
if(n/10>0){
convert(n/10);}
c=n%10+48;
cout<<c;
}

